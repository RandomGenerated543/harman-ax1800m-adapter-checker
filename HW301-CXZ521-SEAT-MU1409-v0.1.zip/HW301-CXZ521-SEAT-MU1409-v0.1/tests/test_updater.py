import base64,contextlib,hashlib,http.server,importlib.util,io,json,threading,unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('adapter',P/'adapter.py');A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)
class Fake(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def respond(self,value):
  data=json.dumps(value).encode();self.send_response(200);self.end_headers();self.wfile.write(data)
 def do_GET(self):
  self.server.gets.append(self.path)
  if self.path=='/getboxinfos':return self.respond({'appversionstr':self.server.app,'appversioncode':126,'sysversionstr':'20250320','btversion':'20240910'})
  self.send_response(404);self.end_headers()
 def do_POST(self):
  data=self.rfile.read(int(self.headers['Content-Length']));self.server.posts.append((self.path,data))
  if self.path=='/uploadappdatas':
   d=json.loads(data);raw=base64.b64decode(d['data']);assert len(raw)==d['datasize'];assert b'": ' not in data
   if d['pos']==self.server.reject:return self.respond({'result':0,'pos':d['pos']})
   self.server.upload.extend(raw);return self.respond({'result':1,'pos':d['pos']})
  if self.path=='/requestupdate':return self.respond(self.server.progress.pop(0))
  return self.respond({'result':0})
class UpdaterTests(unittest.TestCase):
 def setUp(self):
  self.server=http.server.HTTPServer(('127.0.0.1',0),Fake);s=self.server;s.gets=[];s.posts=[];s.upload=bytearray();s.app='20250630126';s.reject=-1;s.progress=[{'percent':v,'version':2129} for v in [10,50,100]]
  self.thread=threading.Thread(target=s.serve_forever,daemon=True);self.thread.start();self.client=A.Client('127.0.0.1:'+str(s.server_port));self.r,self.blob=A.image_info(P,'candidate')
 def tearDown(self):self.server.shutdown();self.server.server_close();self.thread.join()
 def test_dry_run_offline(self):
  old=A.Client
  try:
   A.Client=lambda *a:(_ for _ in ()).throw(AssertionError('network touched'))
   self.assertEqual(A.main(['dry-run']),0)
  finally:A.Client=old
  self.assertFalse(self.server.gets or self.server.posts)
 def test_full_protocol(self):
  A.write_image(self.client,self.r,self.blob,pause=lambda x:None)
  self.assertEqual(bytes(self.server.upload),self.blob)
  self.assertEqual(self.server.gets,['/getboxinfos'])
  self.assertEqual(sum(p=='/requestupdate' for p,b in self.server.posts),3)
 def test_wrong_base_no_post(self):
  self.server.app='unmatched'
  with self.assertRaises(A.DeviceError):A.write_image(self.client,self.r,self.blob)
  self.assertFalse(self.server.posts)
 def test_chunk_rejected_no_flash(self):
  self.server.reject=1
  with self.assertRaises(A.DeviceError):A.write_image(self.client,self.r,self.blob)
  self.assertFalse(any(p=='/requestupdate' for p,b in self.server.posts))
 def test_progress_reset_not_success(self):
  self.server.progress=[{'percent':50},{'percent':0}]
  with self.assertRaises(A.DeviceError):A.write_image(self.client,self.r,self.blob,pause=lambda x:None)
 def test_bad_progress_not_success(self):
  self.server.progress=[{'result':0}]
  with self.assertRaises(A.DeviceError):A.write_image(self.client,self.r,self.blob,pause=lambda x:None)
 def test_external_host_refused(self):
  with self.assertRaises(A.DeviceError):A.Client('8.8.8.8')
if __name__=='__main__':
 with contextlib.redirect_stdout(io.StringIO()):
  suite=unittest.defaultTestLoader.loadTestsFromTestCase(UpdaterTests);result=unittest.TextTestRunner(verbosity=2).run(suite)
 (P/'out/UPDATER-TESTS.json').write_text(json.dumps({'tests':result.testsRun,'pass':result.wasSuccessful(),'scope':'loopback fake adapter only; no hardware accessed'},indent=2)+'\n')
 raise SystemExit(0 if result.wasSuccessful() else 1)
