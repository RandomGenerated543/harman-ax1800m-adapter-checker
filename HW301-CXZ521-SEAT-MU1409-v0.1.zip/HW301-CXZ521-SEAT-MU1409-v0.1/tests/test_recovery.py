import importlib.util,json,struct,sys,tempfile,unittest,zlib
from pathlib import Path
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P));import recovery as R
def fixture():
 data=bytearray(b'\xff'*0x1000000);entries=bytearray(128*128);entries[:16]=b'A'*16;entries[16:32]=b'B'*16
 struct.pack_into('<QQ',entries,32,0x7e0000//512,0xea0000//512-1);name='app'.encode('utf-16-le');entries[56:56+len(name)]=name
 data[1024:1024+len(entries)]=entries;h=bytearray(512);h[:8]=b'EFI PART';struct.pack_into('<I',h,8,0x10000);struct.pack_into('<I',h,12,92);struct.pack_into('<Q',h,72,2);struct.pack_into('<III',h,80,128,128,zlib.crc32(entries)&0xffffffff);struct.pack_into('<I',h,16,zlib.crc32(h[:92])&0xffffffff);data[512:1024]=h
 return data
class RecoveryTests(unittest.TestCase):
 def test_layout(self):self.assertEqual(R.layout(fixture()),(0x7e0000,0x6c0000))
 def test_bad_crc(self):
  d=fixture();d[512+40]^=1
  with self.assertRaises(ValueError):R.layout(d)
 def test_bad_entries(self):
  d=fixture();d[1024+70]^=1
  with self.assertRaises(ValueError):R.layout(d)
 def test_preserve_erase_block_tail(self):
  d=fixture();d[0x7e0000:0xea0000]=b'\xa5'*0x6c0000
  with tempfile.TemporaryDirectory(dir=P/'tmp') as td:
   td=Path(td);dump=td/'flash.bin';dump.write_bytes(d);start,image=R.prepare(dump,td/'aligned.bin')
   self.assertEqual(start,0x7e0000);self.assertEqual(len(image)%0x10000,0);self.assertEqual(dump.read_bytes(),d)
   self.assertTrue(image.endswith(b'\xa5'*128));self.assertEqual(image[:4],b'hsqs')
if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(RecoveryTests));(P/'out/RECOVERY-TESTS.json').write_text(json.dumps({'tests':result.testsRun,'pass':result.wasSuccessful(),'scope':'synthetic GPT/local image only; no USB access'},indent=2)+'\n');raise SystemExit(0 if result.wasSuccessful() else 1)
