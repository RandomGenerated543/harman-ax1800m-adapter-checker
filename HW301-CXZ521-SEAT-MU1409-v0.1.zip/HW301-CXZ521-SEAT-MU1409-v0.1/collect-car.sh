#!/bin/ksh
# Passive collection only. Run through SSH stdin; output stays on the Mac.
# Does not source runtime scripts, inject controls, restart anything, or write files.
LABEL=${1:-unspecified}
case "$LABEL" in wired|wireless|unspecified) ;;*) echo 'COLLECT=FAIL label_must_be_wired_or_wireless';exit 2;;esac
BASE=/mnt/app/root/altscreen-u2
show_file(){
 echo "FILE=$1"
 if [ -r "$1" ];then cat "$1";else echo MISSING;fi
}
snapshot(){
 echo "SNAPSHOT=$1"
 for F in /tmp/mibr-alt111-gen2.status /tmp/mibr-carplay111.state /tmp/mibr-carplay111.heartbeat /tmp/mibr-direct-auto.state /tmp/mibr-direct-remux.status /tmp/mibr-isotx2-gate.stats;do show_file "$F";done
}
echo "WIRELESS_ASSESSMENT=v1 connection=$LABEL production_writes=0 input_injection=0"
date
echo 'RECEIVER_IDENTITIES'
SHA=$BASE/bin/sha256sum
if [ -x "$SHA" ];then "$SHA" /mnt/app/eso/lib/libairplay.so /mnt/app/eso/lib/libmibr_carplay111.so "$BASE/bin/libaltscreen111.so";else echo SHA_HELPER_MISSING;fi
echo 'RELEVANT_PROCESSES'
pidin ar | grep -E '[d]io_manager|[s]martphone_integrator|[d]isplaymanager|[d]irect-ts|[d]irect_ts_auto|[i]o-usb|[u]sblauncher'
echo 'INTERFACES'
if command -v ifconfig >/dev/null 2>&1;then ifconfig -a;else echo IFCONFIG_UNAVAILABLE;fi
echo 'TCP_LISTENERS_AND_CONNECTIONS'
if [ -x /usr/sbin/netstat ];then /usr/sbin/netstat -an | grep -E '6031|19820|19821|19822|5000|5001';else echo NETSTAT_UNAVAILABLE;fi
echo 'ACTIVE_FIREWALL_RULES'
if [ -x /armle/sbin/pfctl ];then /armle/sbin/pfctl -sr;else echo PFCTL_UNAVAILABLE;fi
snapshot before
sleep 5
snapshot after
echo 'RECEIVER_NEGOTIATION_AND_VIDEO'
if [ -r /tmp/altscreen111.log ];then
 grep -E 'GEN2 candidate active:|GEN2 /info ready:|stock display capability|SETUP entry|SETUP stock result|SETUP contains stream111|SETUP accepted|SETUP fail-soft|no captured session AES key|cannot bind|waiting for iPhone AltScreen|AltScreen stream 111 connected|AltScreen accept failed|transactional video config|gen2 UI|QUEUE_RECOVERY|renderer consumer|GEN2 TEARDOWN|SEAT_VIEW|MAIN_ZOOM|ZOOM_FACTOR|IOS_ZOOM_TEST' /tmp/altscreen111.log | tail -200
else echo RECEIVER_LOG_MISSING;fi
echo 'SUPERVISOR_HISTORY'
LOGROOT=/fs/tmpfs/mibr-altscreen-logs/direct-ts
if [ -r "$BASE/config/deployment_media_root" ];then
 MEDIA=$(cat "$BASE/config/deployment_media_root")
 case "$MEDIA" in /net/mmx/fs/*|/fs/*) [ ! -d "$MEDIA/mhi2-altscreen-logs/direct-ts" ] || LOGROOT=$MEDIA/mhi2-altscreen-logs/direct-ts;;esac
fi
if [ -r "$LOGROOT/DIRECT-TS.log" ];then tail -70 "$LOGROOT/DIRECT-TS.log";else echo MASTER_LOG_MISSING;fi
echo 'BRIDGE_CURRENT_STATUS'
show_file /tmp/mibr-direct-remux.status
echo 'COLLECT=COMPLETE no_restore_required=1 visible_output=OPERATOR_REPORT_REQUIRED'
