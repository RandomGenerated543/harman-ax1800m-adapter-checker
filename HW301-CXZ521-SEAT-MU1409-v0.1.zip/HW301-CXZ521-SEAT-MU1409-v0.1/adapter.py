#!/usr/bin/env python3
"""Bench-only HW301 app updater. Standard library only; no vendor requests.
No device writes occur without the explicit flash/rollback command.
"""
import argparse,base64,datetime,hashlib,io,ipaddress,json,math,sys,tarfile,time,urllib.request,urllib.parse
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BUILD='seat-mu1409-cxz521-native-v0.1-20261029'
CHUNK=32768
class DeviceError(Exception):pass
class LocalRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  if urllib.parse.urlsplit(req.full_url).netloc!=urllib.parse.urlsplit(newurl).netloc:raise DeviceError('external redirect refused before request')
  return super().redirect_request(req,fp,code,msg,headers,newurl)
def json_body(value):return json.dumps(value,separators=(',',':')).encode()
def image_info(root,kind):
 records=json.loads((root/'IMAGES.json').read_text());r=records[kind];p=root/r['file'];blob=p.read_bytes()
 if hashlib.sha256(blob).hexdigest()!=r['sha256']:raise DeviceError('image SHA256 mismatch')
 with tarfile.open(fileobj=io.BytesIO(blob)) as t:
  members=t.getmembers()
  if [m.name for m in members]!=['app.img','appmd5sum.txt'] or any(not m.isfile() for m in members):raise DeviceError('unexpected OTA tar members')
  img=t.extractfile('app.img').read();md5=t.extractfile('appmd5sum.txt').read().decode().strip()
  if len(img)>0x6c0000 or img[:4]!=b'hsqs' or hashlib.md5(img).hexdigest()!=md5:raise DeviceError('invalid app image')
 return r,blob
class Client:
 def __init__(self,host):
  u=urllib.parse.urlsplit('http://'+host)
  try:address=ipaddress.ip_address(u.hostname)
  except (ValueError,TypeError):raise DeviceError('host must be a local/private numeric IP')
  if not(address.is_private or address.is_loopback) or u.username or u.password or u.path or u.query or u.fragment:raise DeviceError('invalid local host')
  self.base='http://'+host
  self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),LocalRedirect())
 def request(self,path,value=None):
  data=None if value is None else (value if isinstance(value,bytes) else json_body(value))
  req=urllib.request.Request(self.base+'/'+path,data=data,headers={'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','User-Agent':'SEAT-MU1409-local-bench'})
  try:
   with self.opener.open(req,timeout=20) as response:
    if urllib.parse.urlsplit(response.geturl()).netloc!=urllib.parse.urlsplit(self.base).netloc:raise DeviceError('external redirect refused')
    body=response.read(4*1024*1024)
  except Exception as e:raise DeviceError(f'{path}: {e}') from e
  return body
 def data(self,path,value=None):
  try:return json.loads(self.request(path,value))
  except (ValueError,UnicodeError) as e:raise DeviceError(f'{path}: non-JSON reply') from e
def probe(client):
 info=client.data('getboxinfos')
 if not isinstance(info,dict):raise DeviceError('invalid box information')
 shown={k:info.get(k) for k in ['appversionstr','appversioncode','sysversionstr','btversion']}
 print('BOX='+json.dumps(shown,sort_keys=True))
 if str(info.get('appversionstr')) not in ['20250630126','20260122129']:raise DeviceError('unmatched app base; no write performed')
 return info
def write_image(client,r,blob,pause=time.sleep):
 probe(client) # Read-only identity check before the first upload.
 count=math.ceil(len(blob)/CHUNK)
 for pos in range(count):
  raw=blob[pos*CHUNK:(pos+1)*CHUNK]
  frame={'result':1,'version':r['ota_version'],'pos':pos,'itemsize':CHUNK,'count':count,'filesize':len(blob),'datasize':len(raw),'data':base64.b64encode(raw).decode()}
  response=client.data('uploadappdatas',frame)
  if response.get('result')!=1 or response.get('pos')!=pos:raise DeviceError(f'chunk {pos} rejected: {response}')
  if pos%8==0 or pos+1==count:print(f'UPLOAD={pos+1}/{count}',flush=True)
 print('UPLOAD=COMPLETE FLASH=STARTING keep_adapter_powered=1',flush=True)
 previous=-1;changed=time.monotonic();start=changed
 while time.monotonic()-start<300:
  status=client.data('requestupdate',b'')
  if not isinstance(status,dict) or status.get('result',1)==0:raise DeviceError(f'write status rejected: {status}')
  try:pct=float(str(status['percent']).rstrip('%'))
  except (KeyError,TypeError,ValueError):raise DeviceError(f'no valid flash percentage: {status}')
  if not math.isfinite(pct) or pct<0 or pct>100 or pct<previous:raise DeviceError(f'flash progress invalid/reset: {status}')
  if pct!=previous:print(f'FLASH={pct:g}%',flush=True);changed=time.monotonic()
  previous=pct
  if pct==100:
   print('FLASH_REPORTED_COMPLETE=1 build_verification=PENDING power_cycle_only_after_complete=1');return
  if time.monotonic()-changed>60:raise DeviceError('flash progress stalled; result unknown')
  pause(0.25)
 raise DeviceError('flash timed out; result unknown')
def main(argv=None):
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('command',choices=['dry-run','probe','flash','rollback','verify','verify-stock','logs']);ap.add_argument('--host',default='192.168.31.1');ap.add_argument('--out',default='logs');a=ap.parse_args(argv)
 if a.command=='dry-run':
  for kind in ['candidate','rollback']:
   r,b=image_info(ROOT,kind);print(f'IMAGE={kind} file={r["file"]} bytes={len(b)} chunks={math.ceil(len(b)/CHUNK)} sha256={r["sha256"]}')
  print('DRY_RUN=PASS network_requests=0 device_writes=0');return 0
 c=Client(a.host)
 if a.command=='logs':
  stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
  reply=c.data('getlogs',{'datetime':stamp,'carbrand':'SEAT','carmodel':'MU1409-local','carmakeyear':'2020','carproblem':'local diagnostic capture'})
  path=reply.get('logsurl','');u=urllib.parse.urlsplit(path)
  if not path or u.scheme or u.netloc or u.query or u.fragment or '..' in u.path.split('/'):raise DeviceError('unsafe local logs path')
  dest=Path(a.out);dest.mkdir(parents=True,exist_ok=True);tar=dest/Path(u.path).name
  tar.write_bytes(c.request(urllib.parse.quote(u.path.lstrip('/'))))
  with tarfile.open(tar) as t:t.extractall(dest,filter='data')
  print('LOGS_SAVED='+str(dest.resolve())+' vendor_upload=0');return 0
 if a.command=='probe':probe(c);print('PROBE=PASS device_writes=0');return 0
 if a.command in ['flash','rollback']:
  kind='candidate' if a.command=='flash' else 'rollback';r,b=image_info(ROOT,kind);write_image(c,r,b);return 0
 if a.command=='verify':
  marker=c.request('clbuild.txt').decode().strip()
  if marker!=BUILD:raise DeviceError(f'build marker differs: {marker!r}')
  print('BUILD_VERIFIED='+marker+' car_functionality=UNTESTED');return 0
 if a.command=='verify-stock':
  info=probe(c)
  if str(info.get('appversionstr'))!='20250630126':raise DeviceError('original v126 not reported')
  print('STOCK_VERSION_VERIFIED=20250630126');return 0
if __name__=='__main__':
 try:sys.exit(main())
 except DeviceError as e:
  print('ADAPTER=FAIL '+str(e),file=sys.stderr)
  print('If writing had started, retain power and save this output; no automatic retry or success is claimed.',file=sys.stderr);sys.exit(2)
