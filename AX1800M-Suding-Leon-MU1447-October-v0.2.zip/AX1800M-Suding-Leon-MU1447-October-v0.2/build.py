#!/usr/bin/env python3
"""Local build only; this script never contacts or flashes an adapter."""
from pathlib import Path
import hashlib, importlib.util, json, os, shutil, struct, tarfile
P = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
stock = P / 'build-input/stock_ax_202610081657.tar'
assert sha(stock.read_bytes()) == '13ca438ad4db00bbac0fa4650419df110bf17611a69525409261318a8bbade86', 'unmatched base'
dest = P / 'build/stock'
if dest.exists(): shutil.rmtree(dest)
dest.mkdir(parents=True)
with tarfile.open(stock) as t: t.extractall(dest, filter='data')
assert sha((dest/'sdDongle').read_bytes()) == 'edff2ce4ae238d682fdc45be680d4cab919fc1be09bf398aaff4897289390bcb'
os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR', str(P/'build/zig-global'))
os.environ.setdefault('ZIG_LOCAL_CACHE_DIR', str(P/'build/zig-local'))
os.environ['TMPDIR'] = str(P/'tmp')
(P/'tmp').mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('hook_builder', P/'src/build_hook.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
b.main()
patched = P/'build/patched'
for n in b.LIBS: assert (patched/n).read_bytes() == (dest/n).read_bytes(), n
for n in ['sdDongle','libSdHOct.so']:
    blob=(patched/n).read_bytes()
    assert blob[:6] == b'\x7fELF\x01\x01' and struct.unpack_from('<H',blob,18)[0] == 8
assert b'SEAT_CLUSTER_W' not in (P/'src/seat_profile.h').read_bytes()
out=P/'firmware/ax_leon_oct_v02.tar'
# Retain the vendor's GNU tar member ordering; deterministic metadata.
with tarfile.open(out,'w',format=tarfile.GNU_FORMAT) as t:
    for name in b.LIBS+['sdDongle','libSdHOct.so']:
        path=patched/name; ti=t.gettarinfo(path,arcname=name)
        ti.uid=ti.gid=0; ti.uname=ti.gname=''; ti.mtime=0; ti.mode=0o755
        with path.open('rb') as f:t.addfile(ti,f)
with tarfile.open(out) as t:
    for m in t.getmembers():assert t.extractfile(m).read() == (patched/m.name).read_bytes()
records={}
for key,name,version in [('candidate','ax_leon_oct_v02.tar','ax_leon_oct_v02'),('rollback','stock_ax_202610081657.tar','ax_202610081657')]:
    blob=(P/'firmware'/name).read_bytes()
    records[key]={'file':'firmware/'+name,'upload_name':version,'md5':hashlib.md5(blob).hexdigest(),'sha256':sha(blob),'bytes':len(blob)}
(P/'IMAGES.json').write_text(json.dumps(records,indent=2)+'\n')
report={'base':'ax_202610081657','owner_current':'ax_202610081657','intentional_application_downgrade':False,'proxy_source_commit':'321191526ef26f98df87d85cd35d7597e5940ff1','main_stream':'110 stock path','cluster':'111 / actual phone config geometry; Leon advertises 1010x376','display_dictionary_path':'existing head-unit array preserved by upstream branch patch; no live proof','dynamic_car_commands':'NOT_IMPLEMENTED','reconnect':'UNQUALIFIED; power-cycle for pilot','vehicle_tested':False,'images':records,'source_sha256':sha((P/'src/altscreen.c').read_bytes()),'shim_sha256':sha((patched/'libSdHOct.so').read_bytes()),'roundtrip_bytes_match':True}
(P/'validation/BUILD.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
