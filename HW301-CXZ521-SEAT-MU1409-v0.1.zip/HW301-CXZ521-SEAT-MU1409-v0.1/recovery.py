#!/usr/bin/env python3
"""HW301 Allwinner FEL recovery. Bench USB only; GPT verified before any write.
backup reads flash twice; prepare writes only a local image; restore writes app.
"""
import argparse,datetime,hashlib,struct,subprocess,tarfile,io,zlib
from pathlib import Path
import adapter
ROOT=Path(__file__).resolve().parent
def layout(data):
 if len(data)!=0x1000000:raise ValueError('expected the documented 16 MiB flash')
 h=data[512:1024]
 if h[:8]!=b'EFI PART':raise ValueError('GPT header absent')
 size=struct.unpack_from('<I',h,12)[0]
 if not 92<=size<=512:raise ValueError('invalid GPT header size')
 header=bytearray(h[:size]);crc=struct.unpack_from('<I',header,16)[0];struct.pack_into('<I',header,16,0)
 if zlib.crc32(header)&0xffffffff!=crc:raise ValueError('GPT header CRC mismatch')
 lba=struct.unpack_from('<Q',h,72)[0];count,entry_size,table_crc=struct.unpack_from('<III',h,80)
 if not(1<=count<=128 and 128<=entry_size<=1024):raise ValueError('invalid GPT table shape')
 entries=data[lba*512:lba*512+count*entry_size]
 if len(entries)!=count*entry_size or zlib.crc32(entries)&0xffffffff!=table_crc:raise ValueError('GPT entries CRC mismatch')
 found=[]
 for i in range(count):
  e=entries[i*entry_size:(i+1)*entry_size]
  if not any(e[:16]):continue
  name=e[56:128].decode('utf-16-le').split('\0',1)[0]
  if name=='app':
   first,last=struct.unpack_from('<QQ',e,32);found.append((first*512,(last-first+1)*512))
 if found!=[(0x7e0000,0x6c0000)]:raise ValueError('unmatched app partition; do not use the reference write offset')
 return found[0]
def prepare(dump,dest):
 data=Path(dump).read_bytes();start,capacity=layout(data)
 _,blob=adapter.image_info(ROOT,'rollback')
 with tarfile.open(fileobj=io.BytesIO(blob)) as t:img=t.extractfile('app.img').read()
 length=(len(img)+0xffff)&~0xffff
 if length>capacity:raise ValueError('rollback image does not fit app')
 # Preserve the same device's remaining bytes in the final erase block.
 image=img+data[start+len(img):start+length]
 dest=Path(dest);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(image)
 return start,image
def run(xfel,*args):return subprocess.check_output([str(xfel),*map(str,args)],stderr=subprocess.STDOUT,text=True)
def chip(xfel):
 result=run(xfel,'version');print(result.strip())
 if 'V851' not in result and 'V853' not in result:raise ValueError('unmatched FEL CPU family')
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('command',choices=['backup','prepare','restore']);ap.add_argument('--dump',type=Path);ap.add_argument('--out',type=Path,default=Path('recovery'));ap.add_argument('--xfel',type=Path,default=ROOT/'tools/xfel');a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 if a.command=='backup':
  chip(a.xfel);stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S');files=[]
  for i in [1,2]:
   f=a.out/f'flash-{stamp}-{i}.bin';print(run(a.xfel,'spinor','read','0x0','0x1000000',f));files.append(f)
  if files[0].read_bytes()!=files[1].read_bytes():raise ValueError('flash reads differ; no write performed')
  layout(files[0].read_bytes());print('BACKUP_VERIFIED='+str(files[0])+' device_writes=0');return
 if not a.dump:raise ValueError('--dump is required')
 target=a.out/'stock-v126-app-aligned.bin';start,image=prepare(a.dump,target)
 print(f'PREPARED={target} offset={start:#x} bytes={len(image)} sha256={hashlib.sha256(image).hexdigest()}')
 if a.command=='prepare':print('DEVICE_WRITES=0');return
 chip(a.xfel)
 # Verify the current device's GPT before using a dump-derived write offset.
 current=a.out/'current-before-restore.bin';print(run(a.xfel,'spinor','read','0x0','0x1000000',current));layout(current.read_bytes())
 saved=a.dump.read_bytes();live=current.read_bytes()
 # Check the reference immutable boot/rootfs region and private partition.
 # rootfs_data/env/UDISK may legitimately change; none is written by this tool.
 # This is a compatibility check, not cryptographic proof of device identity.
 if saved[:0x730000]!=live[:0x730000] or saved[0x7d0000:0x7e0000]!=live[0x7d0000:0x7e0000]:raise ValueError('dump/device fixed regions differ; no write performed')
 print(run(a.xfel,'spinor','write',hex(start),target))
 back=a.out/'app-readback.bin';print(run(a.xfel,'spinor','read',hex(start),hex(len(image)),back))
 if back.read_bytes()!=image:raise ValueError('app readback mismatch')
 print('APP_RESTORE_READBACK=PASS boot_and_CarPlay=UNTESTED')
if __name__=='__main__':
 try:main()
 except (ValueError,adapter.DeviceError,subprocess.CalledProcessError) as e:raise SystemExit('RECOVERY=FAIL '+str(e))
