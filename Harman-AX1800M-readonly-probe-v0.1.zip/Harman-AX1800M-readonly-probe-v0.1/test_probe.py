import importlib.util
import io
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('probe', ROOT / 'probe-adapter.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)

class Reply:
    status = 200
    headers = {'Server': 'test'}
    def __init__(self, body): self.body = body
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, n): return self.body[:n]

class Opener:
    def __init__(self, version='20260109175612'): self.calls = []; self.version = version
    def open(self, req, timeout):
        self.calls.append((req.full_url, req.get_method(), req.data))
        if req.full_url.endswith('getversion.cgi'):
            return Reply(('platform:AX1800M\ncustom:suding\nsystem_version:202603120956CA\nprotocol_version:' + self.version).encode())
        return Reply(b'<html>settings</html>')

class Tests(unittest.TestCase):
    def test_public_target_rejected(self):
        for host in ('8.8.8.8', '192.168.50.100/path', 'example.com'):
            with self.assertRaises(ValueError): probe.local_host(host)
    def test_readonly_request_set(self):
        opener = Opener()
        with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
            out = Path(tmp) / 'capture'
            with patch.object(sys, 'argv', ['probe', '--out', str(out)]), patch('urllib.request.build_opener', return_value=opener), patch.object(probe, 'banner', return_value={'open': False}) as banners, patch('sys.stdout', io.StringIO()):
                probe.main()
            self.assertEqual([(url.split('100')[-1], method, body) for url, method, body in opener.calls], [('/cgi-bin/getversion.cgi', 'GET', None), ('/', 'GET', None)])
            self.assertEqual([x.args[1] for x in banners.call_args_list], [22, 23])
            self.assertTrue((out / 'REPORT.json').is_file())
    def test_wrong_identity_stops_before_port_checks(self):
        opener = Opener('other')
        with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
            with patch.object(sys, 'argv', ['probe', '--out', str(Path(tmp) / 'capture')]), patch('urllib.request.build_opener', return_value=opener), patch.object(probe, 'banner') as banners:
                with self.assertRaises(ValueError): probe.main()
                self.assertEqual(len(opener.calls), 1)
                banners.assert_not_called()
    def test_dry_run_has_no_network(self):
        with patch.object(sys, 'argv', ['probe', '--dry-run']), patch('urllib.request.build_opener') as opener, patch.object(probe, 'banner') as banners, patch('sys.stdout', io.StringIO()):
            probe.main()
            opener.assert_not_called(); banners.assert_not_called()
    def test_connection_check_sends_no_login_data(self):
        class Conn:
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def settimeout(self, n): pass
            def recv(self, n): return b'SSH-2.0-test\r\n'
            def send(self, data): raise AssertionError('Must not transmit login data')
        with patch('socket.create_connection', return_value=Conn()):
            self.assertEqual(probe.banner('192.168.50.100', 22)['banner'], 'SSH-2.0-test\r\n')

if __name__ == '__main__': unittest.main()
